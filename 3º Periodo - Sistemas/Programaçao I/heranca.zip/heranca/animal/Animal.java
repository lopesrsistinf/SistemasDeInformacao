package animal;

public class Animal {
    protected String tipo;

    public Animal() {
        tipo = null;
    }

    public Animal(String tipo) {
        this.tipo = tipo+" morto";
    }

    protected void emiteSom() {
        System.out.println("ruido");
    }

    @Override
    public String toString() {
        return "Sou um animal!";
    }
}
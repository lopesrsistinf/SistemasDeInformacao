import novoAnimal.Animal;

public class Main{
    public static void main(String[] args) {
        Animal c = new Animal("caramelo", "mamifero");
        System.out.println(c.getTipo());
        c.emiteSom();
        System.out.println(c.toString());
    }
}
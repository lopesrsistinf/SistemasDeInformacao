package novoAnimal;

//import animal.*;

public class Animal extends animal.Animal {
    String raca;

    public Animal(String raca, String tipo) {
        super(tipo);
        this.raca = raca;
        System.out.println(">>>"+this.tipo);
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    @Override
    public void emiteSom() {
        super.emiteSom();
        System.out.println("latir");
    }

    @Override
    public String toString() {
        return "Sou um cachorro!";
    }

}
public final class Caramelo extends Cachorro
implements Poderoso {

    public Caramelo(int idade) {
        super(idade);
    }

    public void racao() {
        System.out.println("Qualquer coisa comestível");
    }

    public void tipoCriatura() {
        System.out.println(TIPO);
    }

    //cumprindo o contrato de Poderoso
    @Override
    public void poder() {
        System.out.println("ficar invisivel");
    }

    //o metodo invocar de Poderoso não pode ser
    // sobrescrito, mas pode ser invocado
    // https://www.geeksforgeeks.org/java/interfaces-in-java/
    public void invocar() {
        Poderoso.invocar();
    }

    //pode ser sobrescrito ou não
    @Override
    public void ativar() {
        System.out.println("ativando...");
    }

    //***  erro: pois não pode ser mais sobrescrito
    // @Override
    // public void fazerSom() {
    //     System.out.println("Au Au");
    // }
}
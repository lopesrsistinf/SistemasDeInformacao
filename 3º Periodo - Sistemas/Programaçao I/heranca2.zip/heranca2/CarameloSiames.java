//*** erro: não pode herdar de caramelo

// public class CarameloSiames extends Caramelo {
//    public CarameloSiames(int idade) {
//         super(idade);
//    } 

// }
public class Cachorro extends Animal {

    public Cachorro(int idade) {
        super.idade = idade;
    }

    @Override
    public final void fazerSom() {
        System.out.println("Au Au");
    }
}
//classe abstrata pura: contrato
public interface Poderoso {
    static final String TIPO = "magico";

    void poder();

    static void invocar(){
        System.out.println("voar");
    }

    default void ativar() {
        System.out.println("voando..");
    }
}
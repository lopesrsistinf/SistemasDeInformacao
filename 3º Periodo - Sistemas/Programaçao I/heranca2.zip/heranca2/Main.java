public class Main {
    public static void main(String[] args) {
        Caramelo a = new Caramelo(10);
        a.mostrarIdade();
        a.fazerSom();
        a.comer();
        a.racao();
        a.poder();
        a.invocar();
        a.ativar();
    }
}
public abstract class Animal {
    protected int idade;

    //obriga a sobrescrita
    public abstract void fazerSom();

    public final void comer() {
        System.out.println("Animal comendo...");
    }

    public void mostrarIdade() {
        System.out.println(idade);
    }
}
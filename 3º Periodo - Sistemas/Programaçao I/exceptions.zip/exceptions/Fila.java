public class Fila<T>{
    private No<T> inicio;
    private No<T> fim;
    private int tamanho;

    public Fila() {
        inicio = fim = null;
    }

    public void insere(T valor) throws FalhaDeAlocacaoException {
        No<T> n = new No<>(valor);

        if(n == null)
            throw new FalhaDeAlocacaoException("Memória não alocada!");

        if(inicio == null)
            inicio = fim = n;
        else {
            fim.prox = n;
            fim = n;
        }
        tamanho++;
    }

    public void imprime() {
        No<T> aux = inicio;

        while(aux != null){
            System.out.println(aux.valor+" ");
            aux = aux.prox;
        }
    }

}
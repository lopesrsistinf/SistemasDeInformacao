public class FalhaDeAlocacaoException extends NullPointerException {
    
    public FalhaDeAlocacaoException() {
        super();
    }

    public FalhaDeAlocacaoException(String s) {
        super(s);
    }
}
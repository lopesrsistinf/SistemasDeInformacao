public class Main{

    public static void main(String[] args) {
        Fila<Integer> f = new Fila<>();
        try{
            f.insere(5);
            f.insere(2);
            f.insere(3);
            f.insere(2);
            f.insere(51);
            f.imprime();

        }
        catch(FalhaDeAlocacaoException e) {
            System.out.println(e.getMessage());
        }
    }
}
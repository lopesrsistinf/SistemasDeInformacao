public class Main {
    public static void main(String[] args) {
        OrderedPair<String, Integer> p1 = 
            new OrderedPair<>("idade", 45);

        OrderedPair<String, Double> p2 = 
            new OrderedPair<>("altura", 1.70);

        //OrderedPair<Integer, OrderedPair<String, Integer>> p3 = 
        //    new OrderedPair<>(1, new OrderedPair<>("chave", 123));

        System.out.println(p1.getKey());
        System.out.println(p2.getKey());

        Valor<OrderedPair<String, Integer>> v = new Valor<>(new OrderedPair<>("nome", 123));
        //Valor<String> v = new Valor<>("teste");
        v.imprime();
    }
}
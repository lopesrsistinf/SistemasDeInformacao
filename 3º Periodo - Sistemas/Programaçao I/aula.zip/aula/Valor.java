public class Valor<T> {
    private T i;

    public Valor(T i) {
        this.i = i;
    }

    T imprime(){
        System.out.println("Valor = "+i);
        return i;
    }
}